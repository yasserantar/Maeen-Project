// Maeen Chrome Extension Background Service Worker
// Handles daily alarms, background notification reminders, and tab management

chrome.runtime.onInstalled.addListener(() => {
  // Create daily alarm at 8:00 AM
  chrome.alarms.create('maeen_daily_reminder', {
    periodInMinutes: 24 * 60 // Daily
  });
  console.log('[Maeen Extension] Daily reminder alarm initialized.');
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'maeen_daily_reminder') {
    chrome.notifications.create('maeen_daily_ayah', {
      type: 'basic',
      iconUrl: 'icon128.png',
      title: 'مَعِين | وردك اليومي المبارك 📖',
      message: 'حان موعد صفحة اليوم من القرآن الكريم والحديث النبوي الشريف.. انقر للتدبر والاستماع.',
      priority: 2
    });
  }
});

chrome.notifications.onClicked.addListener((notificationId) => {
  if (notificationId === 'maeen_daily_ayah') {
    chrome.tabs.create({ url: 'https://maeen-app-five.vercel.app/quran' });
  }
});
